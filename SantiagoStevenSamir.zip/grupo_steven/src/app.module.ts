import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { ProfileModule } from './profile/profile.module';

import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    MongooseModule.forRoot(
      'mongodb://Steven:Steven123@ac-u9f7hok-shard-00-00.lxqrtx8.mongodb.net:27017,ac-u9f7hok-shard-00-01.lxqrtx8.mongodb.net:27017,ac-u9f7hok-shard-00-02.lxqrtx8.mongodb.net:27017/db_usuario_jwt?replicaSet=atlas-fa4qon-shard-0&ssl=true&authSource=admin',
    ),
    UsersModule,
    AuthModule,
    ProfileModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
