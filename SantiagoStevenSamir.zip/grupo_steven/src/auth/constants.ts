export const jwtConstants = {
  secret: 'MiClaveParaJWT',
};
